package main

import (
	"log"
	"net/http"
	"task/blockchain"
	"task/routes"
)

func main() {
	// Initialize blockchain
	blockchain.Blockchain = append(blockchain.Blockchain, blockchain.CreateGenesisBlock())

	// Setup routes
	router := routes.SetupRoutes()

	// Start server
	log.Println("Server running on http://localhost:8080")
	log.Fatal(http.ListenAndServe(":8080", router))
}