package blockchain

type Transaction struct {
	DealerID    string  `json:"dealer_id"`
	MSISDN      string  `json:"msisdn"`
	MPIN        string  `json:"mpin"`
	Balance     float64 `json:"balance"`
	Status      string  `json:"status"`
	TransAmount float64 `json:"trans_amount"`
	TransType   string  `json:"trans_type"` // e.g., "credit" or "debit"
	Remarks     string  `json:"remarks"`
	Timestamp   string  `json:"timestamp"`
}