package blockchain

import (
	"crypto/sha256"
	"encoding/hex" 
	"time"
)

type Block struct {
	Index        int           `json:"index"`
	Timestamp    string        `json:"timestamp"`
	Transactions []int			   `json:"transactions"`
	PreviousHash string        `json:"previous_hash"`
	Hash         string        `json:"hash"`
}

var Blockchain []Block

func CreateGenesisBlock() Block {
	genesisBlock := Block{
		Index:        0,
		Timestamp:    time.Now().String(),
		Transactions: []int{},
		PreviousHash: "0",
	}
	genesisBlock.Hash = CalculateHash(genesisBlock)
	return genesisBlock
}

func AddBlock(transactions []int) Block {
	prevBlock := Blockchain[len(Blockchain)-1]
	newBlock := Block{
		Index:        prevBlock.Index + 1,
		Timestamp:    time.Now().String(),
		Transactions: transactions,
		PreviousHash: prevBlock.Hash,
	}
	newBlock.Hash = CalculateHash(newBlock)
	Blockchain = append(Blockchain, newBlock)
	return newBlock
}

func CalculateHash(block Block) string {
	record := string(block.Index) + block.Timestamp + block.PreviousHash
	for _, tx := range block.Transactions {
		record += tx.DealerID + tx.MSISDN + tx.Remarks
	}
	hash := sha256.Sum256([]byte(record))
	return hex.EncodeToString(hash[:])
}