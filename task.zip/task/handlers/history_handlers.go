package handlers

import (
	"encoding/json"
	"net/http"
	"task/blockchain"
	"github.com/gorilla/mux"
)

func GetTransactionHistory(w http.ResponseWriter, r *http.Request) {
	params := mux.Vars(r)
	dealerID := params["dealer_id"]

	var history []blockchain.Transaction
	for _, block := range blockchain.Blockchain {
		for _, tx := range block.Transactions {
			if tx.DealerID == dealerID {
				history = append(history, tx)
			}
		}
	}

	if len(history) == 0 {
		http.Error(w, "No transactions found", http.StatusNotFound)
		return
	}
	json.NewEncoder(w).Encode(history)
}