package handlers

import (
	"encoding/json"
	"net/http"
	"task/blockchain"
)

// CreateAsset handles the creation of a new asset (transaction)
func CreateAsset(w http.ResponseWriter, r *http.Request) {
	var transaction blockchain.Transaction
	if err := json.NewDecoder(r.Body).Decode(&transaction); err != nil {
		http.Error(w, "Invalid input", http.StatusBadRequest)
		return
	}

	transaction.Timestamp = time.Now().String()
	blockchain.AddBlock([]blockchain.Transaction{transaction})

	w.WriteHeader(http.StatusCreated)
	json.NewEncoder(w).Encode(transaction)
}

// GetAssets retrieves all assets (transactions)
func GetAssets(w http.ResponseWriter, r *http.Request) {
	var allAssets []blockchain.Transaction
	for _, block := range blockchain.Blockchain {
		allAssets = append(allAssets, block.Transactions...)
	}
	json.NewEncoder(w).Encode(allAssets)
}

// GetTransactionHistory retrieves the transaction history for a given dealer
func GetTransactionHistory(w http.ResponseWriter, r *http.Request) {
	dealerID := r.URL.Query().Get("dealer_id")

	var history []blockchain.Transaction
	for _, block := range blockchain.Blockchain {
		for _, tx := range block.Transactions {
			if tx.DealerID == dealerID {
				history = append(history, tx)
			}
		}
	}

	if len(history) == 0 {
		http.Error(w, "No transactions found", http.StatusNotFound)
		return
	}
	json.NewEncoder(w).Encode(history)
}