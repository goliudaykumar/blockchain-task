package routes

import (
	"net/http"
	"task/handlers"

	"github.com/gorilla/mux"
)

// SetupRoutes defines all the API routes
func SetupRoutes() *mux.Router {
	router := mux.NewRouter()
	router.HandleFunc("/assets", handlers.CreateAsset).Methods("POST")
	router.HandleFunc("/assets", handlers.GetAssets).Methods("GET")
	router.HandleFunc("/assets/history", handlers.GetTransactionHistory).Methods("GET")
	return router
}